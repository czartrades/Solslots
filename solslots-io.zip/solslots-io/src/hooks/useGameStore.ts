"use client";

import { create } from 'zustand';
import { BetResult, UserStats, LeaderboardEntry } from '@/types';

interface GameState {
  currentBet: number;
  setCurrentBet: (amount: number) => void;
  lastResult: BetResult | null;
  setLastResult: (result: BetResult | null) => void;
  isSpinning: boolean;
  setIsSpinning: (spinning: boolean) => void;
  betHistory: BetResult[];
  addToHistory: (result: BetResult) => void;
  userStats: UserStats;
  updateStats: (result: BetResult) => void;
  serverSeed: string;
  clientSeed: string;
  nonce: number;
  setSeeds: (server: string, client: string) => void;
  incrementNonce: () => void;
  leaderboard: LeaderboardEntry[];
  setLeaderboard: (entries: LeaderboardEntry[]) => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  currentBet: 0.1,
  setCurrentBet: (amount) => set({ currentBet: amount }),
  lastResult: null,
  setLastResult: (result) => set({ lastResult: result }),
  isSpinning: false,
  setIsSpinning: (spinning) => set({ isSpinning: spinning }),
  betHistory: [],
  addToHistory: (result) => set((state) => ({ 
    betHistory: [result, ...state.betHistory].slice(0, 50) 
  })),
  userStats: {
    totalWagered: 0,
    totalWon: 0,
    totalBets: 0,
    winRate: 0,
    bestMultiplier: 0,
    profit: 0,
  },
  updateStats: (result) => set((state) => {
    const newWagered = state.userStats.totalWagered + result.amount;
    const newWon = state.userStats.totalWon + result.payout;
    const newBets = state.userStats.totalBets + 1;
    const newWinRate = ((state.userStats.totalBets * state.userStats.winRate / 100) + (result.win ? 1 : 0)) / newBets * 100;
    const newBestMultiplier = Math.max(state.userStats.bestMultiplier, result.multiplier);
    const newProfit = newWon - newWagered;

    return {
      userStats: {
        totalWagered: newWagered,
        totalWon: newWon,
        totalBets: newBets,
        winRate: newWinRate,
        bestMultiplier: newBestMultiplier,
        profit: newProfit,
      }
    };
  }),
  serverSeed: '',
  clientSeed: '',
  nonce: 0,
  setSeeds: (server, client) => set({ serverSeed: server, clientSeed: client }),
  incrementNonce: () => set((state) => ({ nonce: state.nonce + 1 })),
  leaderboard: [],
  setLeaderboard: (entries) => set({ leaderboard: entries }),
}));
