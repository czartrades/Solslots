"use client";

import { useWallet as useSolWallet, useConnection } from '@solana/wallet-adapter-react';
import { useEffect, useState } from 'react';
import { getBalance, shortenAddress } from '@/lib/solana';

export function useWallet() {
  const { publicKey, connected, connecting, disconnect, wallet } = useSolWallet();
  const { connection } = useConnection();
  const [balance, setBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (publicKey && connected) {
      setIsLoading(true);
      getBalance(publicKey).then(bal => {
        setBalance(bal);
        setIsLoading(false);
      });

      const id = connection.onAccountChange(publicKey, (account) => {
        setBalance(account.lamports / 1e9);
      });

      return () => {
        connection.removeAccountChangeListener(id);
      };
    }
  }, [publicKey, connected, connection]);

  return {
    publicKey,
    connected,
    connecting,
    disconnect,
    wallet,
    balance,
    isLoading,
    address: publicKey?.toBase58() || '',
    shortAddress: publicKey ? shortenAddress(publicKey.toBase58()) : '',
  };
}
