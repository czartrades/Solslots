import { Connection, PublicKey, clusterApiUrl, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getAssociatedTokenAddress, getAccount } from '@solana/spl-token';

export const SOLANA_RPC = process.env.NEXT_PUBLIC_SOLANA_RPC || 'https://api.mainnet-beta.solana.com';
export const DEVNET_RPC = 'https://api.devnet.solana.com';
export const CONNECTION = new Connection(SOLANA_RPC, 'confirmed');
export const DEVNET_CONNECTION = new Connection(DEVNET_RPC, 'confirmed');

export const HOUSE_WALLET = new PublicKey('House111111111111111111111111111111111111111');
export const SLOT_TOKEN_MINT = new PublicKey('Slot111111111111111111111111111111111111111');

export async function getBalance(publicKey: PublicKey): Promise<number> {
  try {
    const balance = await CONNECTION.getBalance(publicKey);
    return balance / LAMPORTS_PER_SOL;
  } catch {
    return 0;
  }
}

export async function getTokenBalance(publicKey: PublicKey, mint: PublicKey): Promise<number> {
  try {
    const ata = await getAssociatedTokenAddress(mint, publicKey);
    const account = await getAccount(CONNECTION, ata);
    return Number(account.amount) / 1e6;
  } catch {
    return 0;
  }
}

export function shortenAddress(address: string, chars = 4): string {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
}

export function isValidSolanaAddress(address: string): boolean {
  try {
    new PublicKey(address);
    return true;
  } catch {
    return false;
  }
}
