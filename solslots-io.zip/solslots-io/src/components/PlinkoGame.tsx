"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { verifyFairness, formatSol } from "@/lib/utils";
import { Play, Settings, History, ArrowDown } from "lucide-react";
import toast from "react-hot-toast";

type RiskLevel = 'low' | 'medium' | 'high';

const ROWS_CONFIG = {
  low: { rows: 8, multipliers: [5.6, 2.1, 1.1, 1.0, 0.5, 1.0, 1.1, 2.1, 5.6] },
  medium: { rows: 12, multipliers: [24, 6.1, 3.0, 1.5, 1.0, 0.5, 0.3, 0.5, 1.0, 1.5, 3.0, 6.1, 24] },
  high: { rows: 16, multipliers: [1000, 130, 26, 9.0, 4.0, 2.0, 1.4, 1.0, 0.2, 1.0, 1.4, 2.0, 4.0, 9.0, 26, 130, 1000] },
};

export function PlinkoGame() {
  const { connected, balance } = useWallet();
  const { 
    currentBet, setCurrentBet,
    isSpinning, setIsSpinning,
    addToHistory, updateStats,
    serverSeed, clientSeed, nonce,
    incrementNonce, setSeeds
  } = useGameStore();

  const [risk, setRisk] = useState<RiskLevel>('medium');
  const [balls, setBalls] = useState<Array<{ id: number; path: number[]; finalSlot: number; active: boolean }>>([]);
  const [ballId, setBallId] = useState(0);
  const boardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!serverSeed) {
      setSeeds(
        "server_seed_plinko_" + Math.random().toString(36).substring(7),
        "client_seed_plinko_" + Math.random().toString(36).substring(7)
      );
    }
  }, []);

  const config = ROWS_CONFIG[risk];

  const dropBall = useCallback(async () => {
    if (!connected) {
      toast.error("Connect your wallet first!");
      return;
    }
    if (balance < currentBet) {
      toast.error("Insufficient SOL balance!");
      return;
    }
    if (isSpinning) return;

    setIsSpinning(true);
    const currentBallId = ballId;
    setBallId(prev => prev + 1);

    // Generate path
    const path: number[] = [];
    let currentSlot = Math.floor(config.rows / 2);

    for (let row = 0; row < config.rows; row++) {
      const hash = verifyFairness(serverSeed, clientSeed, nonce + currentBallId * 100 + row);
      const direction = hash > 0.5 ? 1 : -1;
      currentSlot += direction;
      currentSlot = Math.max(0, Math.min(config.multipliers.length - 1, currentSlot));
      path.push(currentSlot);
    }

    const finalSlot = path[path.length - 1];
    const multiplier = config.multipliers[finalSlot];
    const win = multiplier >= 1;
    const payout = win ? currentBet * multiplier : 0;

    // Add ball to animation
    setBalls(prev => [...prev, { id: currentBallId, path, finalSlot, active: true }]);

    // Wait for animation
    await new Promise(r => setTimeout(r, config.rows * 300 + 500));

    // Remove ball from active
    setBalls(prev => prev.map(b => b.id === currentBallId ? { ...b, active: false } : b));

    const result = {
      win: win,
      amount: currentBet,
      multiplier: multiplier,
      payout: payout,
      outcome: multiplier,
      hash: `${serverSeed}:${clientSeed}:${nonce}`,
      timestamp: Date.now(),
    };

    addToHistory(result);
    updateStats(result);
    incrementNonce();

    if (win) {
      toast.success(`Ball landed in ${multiplier}x! +${formatSol(payout * 1e9)} SOL`);
    } else {
      toast(`Ball landed in ${multiplier}x`);
    }

    setIsSpinning(false);
  }, [connected, balance, currentBet, isSpinning, serverSeed, clientSeed, nonce, risk, config]);

  const getSlotColor = (multiplier: number) => {
    if (multiplier < 1) return 'bg-casino-red/30 text-casino-red border-casino-red/50';
    if (multiplier < 2) return 'bg-gray-800 text-gray-400 border-gray-700';
    if (multiplier < 10) return 'bg-solana-green/20 text-solana-green border-solana-green/50';
    if (multiplier < 50) return 'bg-casino-gold/20 text-casino-gold border-casino-gold/50';
    return 'bg-purple-500/20 text-purple-400 border-purple-500/50';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Plinko</h1>
        <p className="text-gray-400">Drop the ball and watch it bounce!</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="space-y-4">
          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">Bet Amount</h3>
            <div className="flex items-center gap-2 bg-solana-dark rounded-lg p-2 border border-solana-border mb-3">
              <button 
                onClick={() => setCurrentBet(Math.max(0.01, currentBet / 2))}
                className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
              >
                ½
              </button>
              <div className="flex-1 text-center">
                <div className="text-lg font-bold text-white">{currentBet} SOL</div>
              </div>
              <button 
                onClick={() => setCurrentBet(Math.min(100, currentBet * 2))}
                className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
              >
                2x
              </button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[0.1, 0.5, 1, 5].map(amount => (
                <button
                  key={amount}
                  onClick={() => setCurrentBet(amount)}
                  className={`py-2 rounded-lg text-sm font-medium ${
                    currentBet === amount ? 'bg-solana-purple text-white' : 'bg-solana-dark text-gray-400 hover:text-white'
                  }`}
                >
                  {amount}
                </button>
              ))}
            </div>
          </div>

          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">Risk Level</h3>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as RiskLevel[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setRisk(r)}
                  className={`py-3 rounded-lg text-sm font-bold capitalize transition-all ${
                    risk === r 
                      ? r === 'low' ? 'bg-solana-green text-black' :
                        r === 'medium' ? 'bg-casino-gold text-black' :
                        'bg-casino-red text-white'
                      : 'bg-solana-dark text-gray-400 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
            <div className="mt-3 text-xs text-gray-500">
              {risk === 'low' && 'More consistent wins, lower multipliers'}
              {risk === 'medium' && 'Balanced risk and reward'}
              {risk === 'high' && 'Rare big wins, up to 1000x!'}
            </div>
          </div>

          <button
            onClick={dropBall}
            disabled={isSpinning || !connected}
            className="btn-primary w-full text-lg py-4 disabled:opacity-50"
          >
            {isSpinning ? (
              <span className="flex items-center justify-center gap-2">
                <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 0.5, repeat: Infinity }}>
                  <ArrowDown className="w-5 h-5" />
                </motion.div>
                Dropping...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                DROP BALL
              </span>
            )}
          </button>
        </div>

        {/* Board */}
        <div className="lg:col-span-2 gradient-border rounded-xl p-4 bg-solana-card" ref={boardRef}>
          <div className="relative">
            {/* Pegs */}
            <div className="flex flex-col items-center gap-3 py-4">
              {Array(config.rows).fill(0).map((_, row) => (
                <div key={row} className="flex items-center gap-4" style={{ paddingLeft: `${row * 12}px` }}>
                  {Array(row + 1).fill(0).map((_, peg) => (
                    <div key={peg} className="w-3 h-3 rounded-full bg-solana-border" />
                  ))}
                </div>
              ))}
            </div>

            {/* Balls */}
            <AnimatePresence>
              {balls.filter(b => b.active).map((ball) => (
                <motion.div
                  key={ball.id}
                  className="absolute w-4 h-4 rounded-full bg-casino-gold shadow-lg shadow-yellow-500/50 z-10"
                  initial={{ top: 0, left: '50%', x: '-50%' }}
                  animate={{
                    top: `${(ball.path.length + 1) * 48}px`,
                    left: `${(ball.finalSlot / config.multipliers.length) * 100}%`,
                  }}
                  transition={{ duration: ball.path.length * 0.15, ease: "easeInOut" }}
                />
              ))}
            </AnimatePresence>

            {/* Multipliers */}
            <div className="flex justify-center gap-2 mt-4">
              {config.multipliers.map((mult, i) => (
                <motion.div
                  key={i}
                  className={`flex-1 max-w-[60px] py-3 rounded-lg text-center text-sm font-bold border ${getSlotColor(mult)}`}
                  whileHover={{ scale: 1.1 }}
                >
                  {mult}x
                </motion.div>
              ))}
            </div>
          </div>

          {/* Recent Results */}
          <div className="mt-4 pt-4 border-t border-solana-border">
            <div className="flex items-center gap-2 mb-2">
              <History className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-500">Recent Drops</span>
            </div>
            <div className="flex gap-2 overflow-x-auto">
              {balls.slice(-10).map((ball) => (
                <div 
                  key={ball.id}
                  className={`flex-shrink-0 px-2 py-1 rounded text-xs font-bold ${getSlotColor(config.multipliers[ball.finalSlot])}`}
                >
                  {config.multipliers[ball.finalSlot]}x
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
