"use client";

import { motion } from "framer-motion";
import { Gift, Zap, Trophy, Coins, ArrowRight, Sparkles, Crown, Star } from "lucide-react";
import Link from "next/link";

const PROMOTIONS = [
  {
    id: "welcome",
    title: "Welcome Bonus",
    subtitle: "200% First Deposit Match",
    description: "Deposit SOL and get 200% bonus up to 10 SOL. 40x wagering requirement.",
    icon: Gift,
    color: "from-solana-purple to-solana-green",
    bgColor: "bg-solana-purple/10",
    borderColor: "border-solana-purple/30",
    active: true,
    endsIn: "7 days",
  },
  {
    id: "rakeback",
    title: "Daily Rakeback",
    subtitle: "Up to 15% Cashback",
    description: "Get up to 15% of your daily losses back every 24 hours. No wagering required.",
    icon: Coins,
    color: "from-casino-gold to-yellow-600",
    bgColor: "bg-casino-gold/10",
    borderColor: "border-casino-gold/30",
    active: true,
    endsIn: "Ongoing",
  },
  {
    id: "tournament",
    title: "Weekly Tournament",
    subtitle: "50 SOL Prize Pool",
    description: "Compete against other players. Top 10 win SOL prizes based on wagered amount.",
    icon: Trophy,
    color: "from-red-500 to-orange-500",
    bgColor: "bg-red-500/10",
    borderColor: "border-red-500/30",
    active: true,
    endsIn: "3 days",
  },
  {
    id: "vip",
    title: "VIP Program",
    subtitle: "Exclusive Rewards",
    description: "Climb from Bronze to Diamond. Get exclusive bonuses, faster withdrawals, and personal support.",
    icon: Crown,
    color: "from-purple-500 to-pink-500",
    bgColor: "bg-purple-500/10",
    borderColor: "border-purple-500/30",
    active: true,
    endsIn: "Ongoing",
  },
  {
    id: "referral",
    title: "Referral Program",
    subtitle: "Earn 25% Commission",
    description: "Invite friends and earn 25% of house edge from their bets. Lifetime commissions.",
    icon: Star,
    color: "from-blue-500 to-cyan-500",
    bgColor: "bg-blue-500/10",
    borderColor: "border-blue-500/30",
    active: true,
    endsIn: "Ongoing",
  },
  {
    id: "jackpot",
    title: "Progressive Jackpot",
    subtitle: "Current: 1,247 SOL",
    description: "0.1% of every bet goes to the jackpot. Hit the rare combination to win it all.",
    icon: Sparkles,
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-green-500/10",
    borderColor: "border-green-500/30",
    active: true,
    endsIn: "Ongoing",
  },
];

export function Promotions() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold gradient-text mb-4">Promotions</h1>
        <p className="text-xl text-gray-400">Exclusive bonuses and rewards for SolSlots players</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {PROMOTIONS.map((promo, index) => (
          <motion.div
            key={promo.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`gradient-border rounded-xl overflow-hidden ${promo.bgColor} ${promo.borderColor}`}
          >
            <div className={`h-2 bg-gradient-to-r ${promo.color}`} />
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${promo.color}`}>
                  <promo.icon className="w-6 h-6 text-white" />
                </div>
                {promo.active && (
                  <span className="bg-solana-green/20 text-solana-green text-xs font-bold px-2 py-1 rounded-full">
                    Active
                  </span>
                )}
              </div>

              <h3 className="text-xl font-bold text-white mb-1">{promo.title}</h3>
              <p className={`text-lg font-semibold bg-gradient-to-r ${promo.color} bg-clip-text text-transparent mb-3`}>
                {promo.subtitle}
              </p>
              <p className="text-sm text-gray-500 mb-4 leading-relaxed">{promo.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">
                  {promo.endsIn !== "Ongoing" ? `Ends in ${promo.endsIn}` : "Permanent"}
                </span>
                <Link 
                  href={`/promotions/${promo.id}`}
                  className="flex items-center gap-1 text-sm font-medium text-white hover:text-solana-green transition-colors"
                >
                  Learn More
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* VIP Tiers */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold text-white mb-8 text-center">VIP Tiers</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { name: "Bronze", wagered: "0", rakeback: "5%", color: "from-amber-700 to-amber-900" },
            { name: "Silver", wagered: "10", rakeback: "7%", color: "from-gray-400 to-gray-600" },
            { name: "Gold", wagered: "50", rakeback: "10%", color: "from-yellow-500 to-yellow-700" },
            { name: "Platinum", wagered: "250", rakeback: "12%", color: "from-cyan-400 to-blue-600" },
            { name: "Diamond", wagered: "1,000", rakeback: "15%", color: "from-purple-400 to-pink-600" },
          ].map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="gradient-border rounded-xl p-4 text-center"
            >
              <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${tier.color} flex items-center justify-center`}>
                <Crown className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-white mb-1">{tier.name}</h3>
              <div className="text-xs text-gray-500 mb-2">{tier.wagered} SOL wagered</div>
              <div className="text-sm font-bold text-solana-green">{tier.rakeback} Rakeback</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
