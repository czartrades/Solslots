"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { verifyFairness, formatSol } from "@/lib/utils";
import { Play, TrendingUp, TrendingDown, Target, History, Dice5 } from "lucide-react";
import toast from "react-hot-toast";

export function DiceGame() {
  const { connected, balance } = useWallet();
  const { 
    currentBet, setCurrentBet,
    isSpinning, setIsSpinning,
    addToHistory, updateStats,
    serverSeed, clientSeed, nonce,
    incrementNonce, setSeeds
  } = useGameStore();

  const [rollUnder, setRollUnder] = useState(50);
  const [result, setResult] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [winAmount, setWinAmount] = useState(0);

  useEffect(() => {
    if (!serverSeed) {
      setSeeds(
        "server_seed_dice_" + Math.random().toString(36).substring(7),
        "client_seed_dice_" + Math.random().toString(36).substring(7)
      );
    }
  }, []);

  const multiplier = (100 / rollUnder) * 0.99; // 1% house edge
  const winChance = rollUnder;

  const roll = async () => {
    if (!connected) {
      toast.error("Connect your wallet first!");
      return;
    }
    if (balance < currentBet) {
      toast.error("Insufficient SOL balance!");
      return;
    }
    if (isSpinning) return;

    setIsSpinning(true);
    setShowResult(false);
    setResult(null);

    // Animation delay
    await new Promise(r => setTimeout(r, 1500));

    const rollValue = verifyFairness(serverSeed, clientSeed, nonce);
    const isWin = rollValue < rollUnder;
    const payout = isWin ? currentBet * multiplier : 0;

    setResult(rollValue);
    setWinAmount(payout);
    setShowResult(true);

    const betResult = {
      win: isWin,
      amount: currentBet,
      multiplier: isWin ? multiplier : 0,
      payout: payout,
      outcome: rollValue,
      hash: `${serverSeed}:${clientSeed}:${nonce}`,
      timestamp: Date.now(),
    };

    addToHistory(betResult);
    updateStats(betResult);
    incrementNonce();

    if (isWin) {
      toast.success(`Rolled ${rollValue.toFixed(2)}! You won ${formatSol(payout * 1e9)} SOL`);
    } else {
      toast(`Rolled ${rollValue.toFixed(2)}. Over ${rollUnder}!`);
    }

    setIsSpinning(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Dice</h1>
        <p className="text-gray-400">Roll under your target to win</p>
      </div>

      <div className="gradient-border rounded-2xl p-6 bg-solana-card">
        {/* Result Display */}
        <div className="relative h-48 mb-8 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {showResult && result !== null ? (
              <motion.div
                key="result"
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                exit={{ scale: 0, rotate: 180 }}
                className="text-center"
              >
                <div className={`text-7xl font-bold mb-2 ${result < rollUnder ? 'text-solana-green' : 'text-casino-red'}`}>
                  {result.toFixed(2)}
                </div>
                <div className={`text-lg font-medium ${result < rollUnder ? 'text-solana-green' : 'text-casino-red'}`}>
                  {result < rollUnder ? 'YOU WIN!' : 'YOU LOSE'}
                </div>
                {result < rollUnder && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-2 text-casino-gold font-bold text-xl"
                  >
                    +{formatSol(winAmount * 1e9)} SOL
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="dice"
                animate={isSpinning ? { rotate: 360 } : {}}
                transition={isSpinning ? { duration: 0.5, repeat: Infinity, ease: "linear" } : {}}
              >
                <Dice5 className="w-24 h-24 text-solana-purple opacity-50" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Slider */}
        <div className="mb-6">
          <div className="flex justify-between text-sm text-gray-400 mb-2">
            <span>Roll Under</span>
            <span className="text-white font-bold">{rollUnder}</span>
          </div>
          <input
            type="range"
            min="2"
            max="98"
            value={rollUnder}
            onChange={(e) => setRollUnder(Number(e.target.value))}
            className="w-full h-2 bg-solana-dark rounded-lg appearance-none cursor-pointer accent-solana-purple"
            disabled={isSpinning}
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>2</span>
            <span>98</span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-solana-dark rounded-lg p-3 text-center border border-solana-border">
            <div className="text-xs text-gray-500 mb-1">Multiplier</div>
            <div className="text-lg font-bold text-solana-green">{multiplier.toFixed(2)}x</div>
          </div>
          <div className="bg-solana-dark rounded-lg p-3 text-center border border-solana-border">
            <div className="text-xs text-gray-500 mb-1">Win Chance</div>
            <div className="text-lg font-bold text-solana-purple">{winChance.toFixed(1)}%</div>
          </div>
          <div className="bg-solana-dark rounded-lg p-3 text-center border border-solana-border">
            <div className="text-xs text-gray-500 mb-1">Potential Win</div>
            <div className="text-lg font-bold text-casino-gold">{formatSol(currentBet * multiplier * 1e9)} SOL</div>
          </div>
        </div>

        {/* Bet Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
          <div className="flex items-center gap-2 bg-solana-dark rounded-lg p-2 border border-solana-border">
            <button 
              onClick={() => setCurrentBet(Math.max(0.01, currentBet / 2))}
              className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
              disabled={isSpinning}
            >
              ½
            </button>
            <div className="text-center min-w-[100px]">
              <div className="text-lg font-bold text-white">{currentBet} SOL</div>
            </div>
            <button 
              onClick={() => setCurrentBet(Math.min(100, currentBet * 2))}
              className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
              disabled={isSpinning}
            >
              2x
            </button>
          </div>

          <button
            onClick={roll}
            disabled={isSpinning || !connected}
            className="btn-primary flex-1 text-lg py-4 disabled:opacity-50"
          >
            {isSpinning ? (
              <span className="flex items-center justify-center gap-2">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}>
                  <Dice5 className="w-5 h-5" />
                </motion.div>
                Rolling...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                ROLL DICE
              </span>
            )}
          </button>
        </div>

        {/* Provably Fair */}
        <div className="bg-solana-dark rounded-lg p-3 border border-solana-border">
          <div className="flex items-center gap-2 mb-1">
            <History className="w-4 h-4 text-solana-green" />
            <span className="text-xs text-solana-green">Provably Fair</span>
          </div>
          <div className="text-xs font-mono text-gray-600 truncate">
            {serverSeed ? `${serverSeed.slice(0, 30)}...` : 'Initializing...'}
          </div>
        </div>
      </div>
    </div>
  );
}
