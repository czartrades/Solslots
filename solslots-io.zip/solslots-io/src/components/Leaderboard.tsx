"use client";

import { motion } from "framer-motion";
import { LeaderboardEntry } from "@/types";
import { Trophy, Crown, Medal, TrendingUp, Flame } from "lucide-react";
import { shortenAddress } from "@/lib/solana";

const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, address: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU", username: "WhaleKing", wagered: 45000, profit: 12500, multiplier: 420, avatar: "👑" },
  { rank: 2, address: "8ZtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsV", username: "SolMaster", wagered: 32000, profit: 8900, multiplier: 234, avatar: "🥈" },
  { rank: 3, address: "9YtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsW", username: "CryptoQueen", wagered: 28000, profit: 6700, multiplier: 156, avatar: "🥉" },
  { rank: 4, address: "1XtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsX", username: "DegenLife", wagered: 21000, profit: 3400, multiplier: 89, avatar: "🎰" },
  { rank: 5, address: "2WtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsY", username: "MoonBoi", wagered: 18500, profit: 2100, multiplier: 67, avatar: "🚀" },
  { rank: 6, address: "3VtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsZ", username: "SlotSlayer", wagered: 15000, profit: 1800, multiplier: 45, avatar: "💎" },
  { rank: 7, address: "4UtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsA", username: "CrashKing", wagered: 12000, profit: 1200, multiplier: 34, avatar: "💥" },
  { rank: 8, address: "5TtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsB", username: "PlinkoPro", wagered: 9800, profit: 900, multiplier: 28, avatar: "🔵" },
  { rank: 9, address: "6StKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsC", username: "DiceDevil", wagered: 7500, profit: 600, multiplier: 22, avatar: "🎲" },
  { rank: 10, address: "7RtKtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsD", username: "LuckyLuke", wagered: 5200, profit: 400, multiplier: 18, avatar: "🍀" },
];

export function Leaderboard() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Leaderboard</h1>
        <p className="text-gray-400">Top players this week</p>
      </div>

      {/* Top 3 Podium */}
      <div className="flex justify-center items-end gap-4 mb-12">
        {MOCK_LEADERBOARD.slice(0, 3).map((player, index) => (
          <motion.div
            key={player.rank}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`text-center ${index === 0 ? 'order-2' : index === 1 ? 'order-1' : 'order-3'}`}
          >
            <div className={`relative mx-auto mb-3 ${index === 0 ? 'w-24 h-24' : 'w-20 h-20'}`}>
              <div className={`w-full h-full rounded-full flex items-center justify-center text-4xl ${
                index === 0 ? 'bg-gradient-to-br from-yellow-400 to-yellow-600' :
                index === 1 ? 'bg-gradient-to-br from-gray-300 to-gray-500' :
                'bg-gradient-to-br from-amber-600 to-amber-800'
              }`}>
                {player.avatar}
              </div>
              <div className={`absolute -top-2 -right-2 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                index === 0 ? 'bg-yellow-500 text-black' :
                index === 1 ? 'bg-gray-400 text-black' :
                'bg-amber-700 text-white'
              }`}>
                {player.rank}
              </div>
            </div>
            <div className="font-bold text-white">{player.username}</div>
            <div className="text-sm text-gray-500">{shortenAddress(player.address)}</div>
            <div className="mt-2 text-solana-green font-bold">+{player.profit.toLocaleString()} SOL</div>
            <div className="text-xs text-gray-500">{player.multiplier}x max</div>
          </motion.div>
        ))}
      </div>

      {/* Full Table */}
      <div className="gradient-border rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-solana-dark">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Rank</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Player</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Wagered</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Profit</th>
              <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Best Multiplier</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-solana-border">
            {MOCK_LEADERBOARD.map((player, index) => (
              <motion.tr
                key={player.rank}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="hover:bg-white/5 transition-colors"
              >
                <td className="px-4 py-4">
                  <div className="flex items-center gap-2">
                    {player.rank <= 3 ? (
                      <Crown className={`w-5 h-5 ${
                        player.rank === 1 ? 'text-yellow-500' :
                        player.rank === 2 ? 'text-gray-400' :
                        'text-amber-700'
                      }`} />
                    ) : (
                      <span className="text-gray-500 font-mono w-5 text-center">{player.rank}</span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{player.avatar}</span>
                    <div>
                      <div className="font-medium text-white">{player.username}</div>
                      <div className="text-xs text-gray-500">{shortenAddress(player.address)}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-4 text-right text-gray-400 font-mono">
                  {player.wagered.toLocaleString()} SOL
                </td>
                <td className="px-4 py-4 text-right">
                  <span className="text-solana-green font-bold font-mono">+{player.profit.toLocaleString()} SOL</span>
                </td>
                <td className="px-4 py-4 text-right">
                  <span className="inline-flex items-center gap-1 text-casino-gold font-bold">
                    <Flame className="w-4 h-4" />
                    {player.multiplier}x
                  </span>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
