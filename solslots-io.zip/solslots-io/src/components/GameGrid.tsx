"use client";

import { motion } from "framer-motion";
import { GameCard } from "./GameCard";
import { Game } from "@/types";
import { Flame, Zap, Crown, Diamond } from "lucide-react";
import { useState } from "react";

const GAMES: Game[] = [
  { id: "slots", name: "Solana Slots", category: "originals", image: "/images/games/slots.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 100, isLive: true, players: 234 },
  { id: "dice", name: "Dice", category: "originals", image: "/images/games/dice.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 500, isLive: true, players: 156 },
  { id: "crash", name: "Crash", category: "originals", image: "/images/games/crash.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 1000, isLive: true, players: 89 },
  { id: "plinko", name: "Plinko", category: "originals", image: "/images/games/plinko.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 100, isLive: true, players: 67 },
  { id: "keno", name: "Keno", category: "originals", image: "/images/games/keno.jpg", houseEdge: 1.5, minBet: 0.01, maxBet: 50, isLive: false, players: 23 },
  { id: "roulette", name: "Roulette", category: "live", image: "/images/games/roulette.jpg", houseEdge: 2.7, minBet: 0.1, maxBet: 100, isLive: true, players: 45 },
  { id: "blackjack", name: "Blackjack", category: "live", image: "/images/games/blackjack.jpg", houseEdge: 0.5, minBet: 0.1, maxBet: 50, isLive: true, players: 34 },
  { id: "baccarat", name: "Baccarat", category: "live", image: "/images/games/baccarat.jpg", houseEdge: 1.06, minBet: 0.1, maxBet: 100, isLive: true, players: 12 },
  { id: "sweet-bonanza", name: "Sweet Bonanza", category: "slots", image: "/images/games/sweet-bonanza.jpg", houseEdge: 3.5, minBet: 0.1, maxBet: 100, isLive: false, players: 445 },
  { id: "gates-of-olympus", name: "Gates of Olympus", category: "slots", image: "/images/games/gates-of-olympus.jpg", houseEdge: 3.5, minBet: 0.1, maxBet: 100, isLive: false, players: 312 },
  { id: "big-bass-bonanza", name: "Big Bass Bonanza", category: "slots", image: "/images/games/big-bass.jpg", houseEdge: 3.5, minBet: 0.1, maxBet: 100, isLive: false, players: 198 },
  { id: "wanted-dead", name: "Wanted Dead or a Wild", category: "slots", image: "/images/games/wanted.jpg", houseEdge: 3.5, minBet: 0.1, maxBet: 100, isLive: false, players: 156 },
];

const CATEGORIES = [
  { id: "all", label: "All Games", icon: Zap },
  { id: "originals", label: "Originals", icon: Flame },
  { id: "slots", label: "Slots", icon: Diamond },
  { id: "live", label: "Live Casino", icon: Crown },
];

export function GameGrid() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredGames = GAMES.filter(game => {
    const matchesCategory = activeCategory === "all" || game.category === activeCategory;
    const matchesSearch = game.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">All Games</h1>
        <p className="text-gray-400">Choose from {GAMES.length} provably fair games</p>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search games..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-solana-card border border-solana-border rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-solana-purple"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-solana-purple text-white'
                  : 'bg-solana-card text-gray-400 hover:text-white border border-solana-border'
              }`}
            >
              <cat.icon className="w-4 h-4" />
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Games Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredGames.map((game, index) => (
          <GameCard key={game.id} game={game} index={index} />
        ))}
      </div>

      {filteredGames.length === 0 && (
        <div className="text-center py-16">
          <p className="text-gray-500 text-lg">No games found matching your criteria</p>
        </div>
      )}
    </div>
  );
}
