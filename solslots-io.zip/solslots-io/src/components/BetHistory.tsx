"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useGameStore } from "@/hooks/useGameStore";
import { formatSol, shortenAddress } from "@/lib/utils";
import { History, TrendingUp, TrendingDown, Clock } from "lucide-react";
import { useEffect, useState } from "react";

const MOCK_LIVE_BETS = [
  { user: "WhaleKing", game: "Crash", bet: 5, multiplier: 12.5, payout: 62.5, win: true, time: "2s ago" },
  { user: "SolMaster", game: "Slots", bet: 0.5, multiplier: 0, payout: 0, win: false, time: "5s ago" },
  { user: "CryptoQueen", game: "Dice", bet: 2, multiplier: 1.98, payout: 3.96, win: true, time: "8s ago" },
  { user: "DegenLife", game: "Plinko", bet: 1, multiplier: 0.2, payout: 0.2, win: false, time: "12s ago" },
  { user: "MoonBoi", game: "Crash", bet: 10, multiplier: 3.45, payout: 34.5, win: true, time: "15s ago" },
  { user: "SlotSlayer", game: "Slots", bet: 0.2, multiplier: 50, payout: 10, win: true, time: "18s ago" },
  { user: "CrashKing", game: "Crash", bet: 3, multiplier: 0, payout: 0, win: false, time: "22s ago" },
  { user: "PlinkoPro", game: "Plinko", bet: 0.5, multiplier: 24, payout: 12, win: true, time: "25s ago" },
];

export function BetHistory() {
  const { betHistory } = useGameStore();
  const [liveBets, setLiveBets] = useState(MOCK_LIVE_BETS);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveBets(prev => {
        const newBet = {
          user: ["WhaleKing", "SolMaster", "CryptoQueen", "DegenLife", "MoonBoi"][Math.floor(Math.random() * 5)],
          game: ["Crash", "Slots", "Dice", "Plinko"][Math.floor(Math.random() * 4)],
          bet: [0.1, 0.5, 1, 2, 5, 10][Math.floor(Math.random() * 6)],
          multiplier: Math.random() > 0.5 ? parseFloat((Math.random() * 20).toFixed(2)) : 0,
          payout: 0,
          win: Math.random() > 0.4,
          time: "Just now",
        };
        newBet.payout = newBet.win ? newBet.bet * newBet.multiplier : 0;
        return [newBet, ...prev].slice(0, 8);
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const allBets = [...betHistory.slice(0, 5).map(b => ({
    user: "You",
    game: "Game",
    bet: b.amount,
    multiplier: b.multiplier,
    payout: b.payout,
    win: b.win,
    time: "Just now",
  })), ...liveBets];

  return (
    <div className="gradient-border rounded-xl bg-solana-card overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-solana-border">
        <History className="w-4 h-4 text-solana-green" />
        <span className="text-sm font-semibold text-white">Live Bets</span>
        <span className="ml-auto flex items-center gap-1 text-xs text-gray-500">
          <span className="w-1.5 h-1.5 rounded-full bg-solana-green animate-pulse" />
          Live
        </span>
      </div>

      <div className="divide-y divide-solana-border">
        <AnimatePresence>
          {allBets.slice(0, 10).map((bet, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors"
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                bet.win ? 'bg-solana-green/20 text-solana-green' : 'bg-casino-red/20 text-casino-red'
              }`}>
                {bet.user[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white truncate">{bet.user}</span>
                  <span className="text-xs text-gray-500">{bet.game}</span>
                </div>
                <div className="flex items-center justify-between mt-0.5">
                  <span className="text-xs text-gray-500">{formatSol(bet.bet * 1e9)} SOL</span>
                  <span className={`text-xs font-bold ${
                    bet.win ? 'text-solana-green' : 'text-casino-red'
                  }`}>
                    {bet.win ? (
                      <span className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        +{formatSol(bet.payout * 1e9)}
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" />
                        -{formatSol(bet.bet * 1e9)}
                      </span>
                    )}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
