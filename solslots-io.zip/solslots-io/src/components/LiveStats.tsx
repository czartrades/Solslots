"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Coins, Users, TrendingUp, Zap } from "lucide-react";

export function LiveStats() {
  const [stats, setStats] = useState({
    wagered: 2847293,
    players: 1247,
    online: 892,
    biggestWin: 4200,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        wagered: prev.wagered + Math.floor(Math.random() * 100),
        players: prev.players + (Math.random() > 0.5 ? 1 : -1),
        online: prev.online + (Math.random() > 0.5 ? 1 : -1),
        biggestWin: prev.biggestWin,
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(2) + "M";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return num.toString();
  };

  return (
    <div className="bg-solana-card border-y border-solana-border">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-center gap-8 overflow-x-auto">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-solana-green" />
            <span className="text-xs text-gray-500">Total Wagered</span>
            <span className="text-sm font-bold text-solana-green font-mono">{formatNumber(stats.wagered)} SOL</span>
          </div>
          <div className="w-px h-4 bg-solana-border" />
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-solana-purple" />
            <span className="text-xs text-gray-500">Players Online</span>
            <span className="text-sm font-bold text-solana-purple font-mono">{stats.online}</span>
          </div>
          <div className="w-px h-4 bg-solana-border" />
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-casino-gold" />
            <span className="text-xs text-gray-500">Biggest Win</span>
            <span className="text-sm font-bold text-casino-gold font-mono">{stats.biggestWin}x</span>
          </div>
          <div className="w-px h-4 bg-solana-border" />
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-white" />
            <span className="text-xs text-gray-500">House Edge</span>
            <span className="text-sm font-bold text-white font-mono">1.0%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
