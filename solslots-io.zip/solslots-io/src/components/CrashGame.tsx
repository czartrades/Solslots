"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { verifyFairness, formatSol } from "@/lib/utils";
import { Play, Zap, TrendingUp, History, Users, AlertTriangle } from "lucide-react";
import toast from "react-hot-toast";

interface CrashPoint {
  multiplier: number;
  crashed: boolean;
}

export function CrashGame() {
  const { connected, balance } = useWallet();
  const { 
    currentBet, setCurrentBet,
    isSpinning, setIsSpinning,
    addToHistory, updateStats,
    serverSeed, clientSeed, nonce,
    incrementNonce, setSeeds
  } = useGameStore();

  const [gameState, setGameState] = useState<'idle' | 'running' | 'crashed'>('idle');
  const [currentMultiplier, setCurrentMultiplier] = useState(1.0);
  const [crashPoint, setCrashPoint] = useState(1.0);
  const [hasCashedOut, setHasCashedOut] = useState(false);
  const [cashedOutAt, setCashedOutAt] = useState(0);
  const [autoCashout, setAutoCashout] = useState(2.0);
  const [history, setHistory] = useState<number[]>([1.45, 2.34, 1.12, 5.67, 1.89, 3.45, 1.23, 8.90, 1.56, 2.78]);
  const [players, setPlayers] = useState(12);

  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  useEffect(() => {
    if (!serverSeed) {
      setSeeds(
        "server_seed_crash_" + Math.random().toString(36).substring(7),
        "client_seed_crash_" + Math.random().toString(36).substring(7)
      );
    }
  }, []);

  const calculateCrashPoint = useCallback(() => {
    const hash = verifyFairness(serverSeed, clientSeed, nonce);
    // House edge: 1% - crash point distribution
    const edge = 0.01;
    const point = 0.99 / (1 - hash * (1 - edge));
    return Math.max(1.0, Math.min(point, 1000));
  }, [serverSeed, clientSeed, nonce]);

  const startGame = () => {
    if (!connected) {
      toast.error("Connect your wallet first!");
      return;
    }
    if (balance < currentBet) {
      toast.error("Insufficient SOL balance!");
      return;
    }
    if (gameState !== 'idle') return;

    const point = calculateCrashPoint();
    setCrashPoint(point);
    setGameState('running');
    setHasCashedOut(false);
    setCashedOutAt(0);
    setCurrentMultiplier(1.0);
    startTimeRef.current = Date.now();

    // Simulate other players
    setPlayers(Math.floor(Math.random() * 20) + 5);

    gameLoopRef.current = setInterval(() => {
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      const mult = Math.pow(1.06, elapsed); // Exponential growth
      setCurrentMultiplier(mult);

      // Auto cashout
      if (mult >= autoCashout && !hasCashedOut && gameState === 'running') {
        cashOut(mult);
      }

      if (mult >= point) {
        endGame(mult);
      }
    }, 50);
  };

  const cashOut = (mult: number) => {
    if (gameState !== 'running' || hasCashedOut) return;

    setHasCashedOut(true);
    setCashedOutAt(mult);

    const payout = currentBet * mult;

    const result = {
      win: true,
      amount: currentBet,
      multiplier: mult,
      payout: payout,
      outcome: mult,
      hash: `${serverSeed}:${clientSeed}:${nonce}`,
      timestamp: Date.now(),
    };

    addToHistory(result);
    updateStats(result);
    toast.success(`Cashed out at ${mult.toFixed(2)}x! +${formatSol(payout * 1e9)} SOL`);
  };

  const endGame = (finalMult: number) => {
    if (gameLoopRef.current) {
      clearInterval(gameLoopRef.current);
    }

    setGameState('crashed');
    setCurrentMultiplier(finalMult);

    if (!hasCashedOut) {
      const result = {
        win: false,
        amount: currentBet,
        multiplier: 0,
        payout: 0,
        outcome: finalMult,
        hash: `${serverSeed}:${clientSeed}:${nonce}`,
        timestamp: Date.now(),
      };
      addToHistory(result);
      updateStats(result);
      toast.error(`Crashed at ${finalMult.toFixed(2)}x!`);
    }

    setHistory(prev => [finalMult, ...prev].slice(0, 20));
    incrementNonce();

    setTimeout(() => {
      setGameState('idle');
      setCurrentMultiplier(1.0);
    }, 3000);
  };

  const manualCashOut = () => {
    if (gameState === 'running' && !hasCashedOut) {
      cashOut(currentMultiplier);
    }
  };

  const getMultiplierColor = (mult: number) => {
    if (mult < 2) return 'text-white';
    if (mult < 5) return 'text-solana-green';
    if (mult < 10) return 'text-casino-gold';
    return 'text-purple-400';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Crash</h1>
        <p className="text-gray-400">Cash out before the rocket crashes!</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Game Area */}
        <div className="lg:col-span-2 gradient-border rounded-2xl p-6 bg-solana-card">
          {/* Graph Area */}
          <div className="relative h-64 bg-solana-dark rounded-xl border border-solana-border mb-4 overflow-hidden">
            {/* Grid lines */}
            <div className="absolute inset-0 opacity-20">
              {[1, 2, 3, 4, 5].map(i => (
                <div key={i} className="absolute w-full border-t border-white" style={{ top: `${i * 20}%` }} />
              ))}
            </div>

            {/* Multiplier Display */}
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div 
                className="text-center"
                animate={gameState === 'running' ? { scale: [1, 1.05, 1] } : {}}
                transition={{ duration: 0.5, repeat: Infinity }}
              >
                <div className={`text-6xl font-bold ${getMultiplierColor(currentMultiplier)}`}>
                  {currentMultiplier.toFixed(2)}x
                </div>
                {gameState === 'crashed' && (
                  <div className="text-casino-red text-xl font-bold mt-2">CRASHED</div>
                )}
                {hasCashedOut && (
                  <div className="text-solana-green text-lg font-bold mt-2">
                    Cashed out at {cashedOutAt.toFixed(2)}x
                  </div>
                )}
              </motion.div>
            </div>

            {/* Live Players */}
            <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/50 rounded-full px-2 py-1">
              <Users className="w-3 h-3 text-gray-400" />
              <span className="text-xs text-gray-300">{players}</span>
            </div>
          </div>

          {/* History */}
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {history.map((h, i) => (
              <div 
                key={i} 
                className={`flex-shrink-0 px-2 py-1 rounded text-xs font-bold ${
                  h < 2 ? 'bg-gray-800 text-gray-400' :
                  h < 5 ? 'bg-solana-green/20 text-solana-green' :
                  h < 10 ? 'bg-casino-gold/20 text-casino-gold' :
                  'bg-purple-500/20 text-purple-400'
                }`}
              >
                {h.toFixed(2)}x
              </div>
            ))}
          </div>

          {/* Controls */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 bg-solana-dark rounded-lg p-2 border border-solana-border mb-2">
                <button 
                  onClick={() => setCurrentBet(Math.max(0.01, currentBet / 2))}
                  className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
                  disabled={gameState !== 'idle'}
                >
                  ½
                </button>
                <div className="flex-1 text-center">
                  <div className="text-lg font-bold text-white">{currentBet} SOL</div>
                </div>
                <button 
                  onClick={() => setCurrentBet(Math.min(100, currentBet * 2))}
                  className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
                  disabled={gameState !== 'idle'}
                >
                  2x
                </button>
              </div>
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2 bg-solana-dark rounded-lg p-2 border border-solana-border mb-2">
                <span className="text-sm text-gray-500">Auto @</span>
                <input
                  type="number"
                  value={autoCashout}
                  onChange={(e) => setAutoCashout(Number(e.target.value))}
                  className="w-20 bg-transparent text-center text-white font-bold"
                  min="1.01"
                  step="0.1"
                  disabled={gameState !== 'idle'}
                />
                <span className="text-sm text-gray-500">x</span>
              </div>
            </div>
          </div>

          <button
            onClick={gameState === 'running' && !hasCashedOut ? manualCashOut : startGame}
            disabled={gameState === 'crashed' || (gameState === 'running' && hasCashedOut)}
            className={`w-full text-lg py-4 rounded-xl font-bold transition-all ${
              gameState === 'running' && !hasCashedOut
                ? 'bg-casino-gold text-black hover:bg-yellow-400 animate-pulse'
                : gameState === 'idle'
                ? 'btn-primary'
                : 'bg-gray-800 text-gray-500 cursor-not-allowed'
            }`}
          >
            {gameState === 'running' && !hasCashedOut ? (
              <span className="flex items-center justify-center gap-2">
                <Zap className="w-5 h-5" />
                CASH OUT @ {currentMultiplier.toFixed(2)}x
              </span>
            ) : gameState === 'idle' ? (
              <span className="flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                START GAME
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                {gameState === 'crashed' ? 'CRASHED' : 'CASHED OUT'}
              </span>
            )}
          </button>
        </div>

        {/* Side Panel */}
        <div className="space-y-4">
          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">How to Play</h3>
            <ul className="space-y-2 text-sm text-gray-500">
              <li className="flex items-start gap-2">
                <span className="text-solana-green">1.</span>
                Set your bet amount
              </li>
              <li className="flex items-start gap-2">
                <span className="text-solana-green">2.</span>
                Click Start Game
              </li>
              <li className="flex items-start gap-2">
                <span className="text-solana-green">3.</span>
                Watch multiplier grow
              </li>
              <li className="flex items-start gap-2">
                <span className="text-solana-green">4.</span>
                Cash out before crash!
              </li>
            </ul>
          </div>

          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">Live Stats</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Next Crash</span>
                <span className="text-white font-mono">{gameState === 'idle' ? '???' : crashPoint.toFixed(2)}x</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Your Bet</span>
                <span className="text-white font-mono">{currentBet} SOL</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Potential Win</span>
                <span className="text-casino-gold font-mono">{formatSol(currentBet * currentMultiplier * 1e9)} SOL</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
