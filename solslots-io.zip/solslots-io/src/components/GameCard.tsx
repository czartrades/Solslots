"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Game } from "@/types";
import { Users, TrendingUp } from "lucide-react";

interface GameCardProps {
  game: Game;
  index: number;
}

export function GameCard({ game, index }: GameCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link href={`/games/${game.id}`}>
        <div className="gradient-border card-hover group cursor-pointer">
          <div className="relative aspect-[4/3] overflow-hidden rounded-xl">
            {/* Game Image Placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-solana-purple/30 to-solana-green/30 flex items-center justify-center">
              <div className="text-6xl font-bold gradient-text opacity-50">
                {game.name[0]}
              </div>
            </div>

            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

            {/* Badges */}
            <div className="absolute top-3 left-3 flex gap-2">
              {game.isLive && (
                <span className="bg-red-500/80 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                  LIVE
                </span>
              )}
              <span className="bg-solana-green/20 text-solana-green text-xs font-bold px-2 py-1 rounded-full">
                {game.houseEdge}% Edge
              </span>
            </div>

            {/* Players */}
            {game.players && (
              <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/50 rounded-full px-2 py-1">
                <Users className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-300">{game.players}</span>
              </div>
            )}

            {/* Bottom Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-lg font-bold text-white mb-1">{game.name}</h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-gray-400">
                  <TrendingUp className="w-4 h-4" />
                  <span>{game.minBet} - {game.maxBet} SOL</span>
                </div>
                <span className="text-xs text-gray-500 uppercase tracking-wider">{game.category}</span>
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
