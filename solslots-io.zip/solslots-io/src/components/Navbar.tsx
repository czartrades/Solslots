"use client";

import { useState } from "react";
import Link from "next/link";
import { useWallet } from "@/hooks/useWallet";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { 
  Menu, X, Zap, Trophy, Gift, Shield, 
  Coins, ChevronDown, Crown, Flame 
} from "lucide-react";
import { cn, formatSol } from "@/lib/utils";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const { connected, balance, shortAddress } = useWallet();

  const navLinks = [
    { href: "/", label: "Home", icon: Zap },
    { href: "/games", label: "Games", icon: Flame },
    { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
    { href: "/promotions", label: "Promotions", icon: Gift },
    { href: "/provably-fair", label: "Provably Fair", icon: Shield },
  ];

  return (
    <nav className="sticky top-0 z-50 glass-panel border-b border-solana-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-solana-purple to-solana-green flex items-center justify-center">
              <Coins className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold gradient-text">SolSlots</span>
            <span className="text-xs bg-solana-green/20 text-solana-green px-2 py-0.5 rounded-full font-mono">.io</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5 transition-all"
              >
                <link.icon className="w-4 h-4" />
                {link.label}
              </Link>
            ))}
          </div>

          {/* Wallet Section */}
          <div className="hidden md:flex items-center gap-4">
            {connected && (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-solana-card border border-solana-border rounded-lg px-3 py-2">
                  <div className="w-2 h-2 rounded-full bg-solana-green animate-pulse" />
                  <span className="text-sm font-mono text-solana-green">{formatSol(balance * 1e9)} SOL</span>
                </div>

                <div className="relative">
                  <button 
                    onClick={() => setShowDropdown(!showDropdown)}
                    className="flex items-center gap-2 bg-solana-card border border-solana-border rounded-lg px-3 py-2 hover:border-solana-purple transition-colors"
                  >
                    <Crown className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm">{shortAddress}</span>
                    <ChevronDown className="w-4 h-4 text-gray-500" />
                  </button>

                  {showDropdown && (
                    <div className="absolute right-0 mt-2 w-48 bg-solana-card border border-solana-border rounded-lg shadow-xl py-1">
                      <Link href="/profile" className="block px-4 py-2 text-sm hover:bg-white/5">Profile</Link>
                      <Link href="/transactions" className="block px-4 py-2 text-sm hover:bg-white/5">Transactions</Link>
                      <Link href="/vip" className="block px-4 py-2 text-sm hover:bg-white/5">VIP Status</Link>
                      <div className="border-t border-solana-border my-1" />
                      <button className="block w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-white/5">Disconnect</button>
                    </div>
                  )}
                </div>
              </div>
            )}

            <WalletMultiButton 
              className="!bg-gradient-to-r !from-solana-purple !to-solana-green !border-none !rounded-lg !px-6 !py-2 !font-semibold !text-white hover:!opacity-90 transition-opacity"
            />
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden border-t border-solana-border bg-solana-dark">
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-gray-400 hover:text-white hover:bg-white/5"
              >
                <link.icon className="w-5 h-5" />
                {link.label}
              </Link>
            ))}
            <div className="pt-3 border-t border-solana-border">
              <WalletMultiButton className="!w-full !bg-gradient-to-r !from-solana-purple !to-solana-green !border-none !rounded-lg !py-3 !font-semibold" />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
