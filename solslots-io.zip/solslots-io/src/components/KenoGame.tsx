"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { verifyFairness, formatSol } from "@/lib/utils";
import { Play, RefreshCw, History, Grid3X3, Sparkles } from "lucide-react";
import toast from "react-hot-toast";

const NUMBERS = Array.from({ length: 40 }, (_, i) => i + 1);

const PAYOUT_TABLE: Record<number, number> = {
  0: 0, 1: 0, 2: 1, 3: 2, 4: 5, 5: 15, 6: 50, 7: 150, 8: 500, 9: 1000, 10: 5000
};

export function KenoGame() {
  const { connected, balance } = useWallet();
  const { 
    currentBet, setCurrentBet,
    isSpinning, setIsSpinning,
    addToHistory, updateStats,
    serverSeed, clientSeed, nonce,
    incrementNonce, setSeeds
  } = useGameStore();

  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([]);
  const [drawnNumbers, setDrawnNumbers] = useState<number[]>([]);
  const [matchedNumbers, setMatchedNumbers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    if (!serverSeed) {
      setSeeds(
        "server_seed_keno_" + Math.random().toString(36).substring(7),
        "client_seed_keno_" + Math.random().toString(36).substring(7)
      );
    }
  }, []);

  const toggleNumber = (num: number) => {
    if (isSpinning) return;
    setSelectedNumbers(prev => {
      if (prev.includes(num)) return prev.filter(n => n !== num);
      if (prev.length >= 10) return prev;
      return [...prev, num].sort((a, b) => a - b);
    });
  };

  const clearSelection = () => {
    if (isSpinning) return;
    setSelectedNumbers([]);
    setDrawnNumbers([]);
    setMatchedNumbers([]);
    setShowResult(false);
  };

  const autoPick = () => {
    if (isSpinning) return;
    const picks = new Set<number>();
    while (picks.size < 8) {
      picks.add(Math.floor(Math.random() * 40) + 1);
    }
    setSelectedNumbers(Array.from(picks).sort((a, b) => a - b));
  };

  const draw = async () => {
    if (!connected) {
      toast.error("Connect your wallet first!");
      return;
    }
    if (balance < currentBet) {
      toast.error("Insufficient SOL balance!");
      return;
    }
    if (selectedNumbers.length < 2) {
      toast.error("Select at least 2 numbers!");
      return;
    }
    if (isSpinning) return;

    setIsSpinning(true);
    setShowResult(false);
    setDrawnNumbers([]);
    setMatchedNumbers([]);

    // Draw 20 numbers
    const drawn: number[] = [];
    const available = [...NUMBERS];

    for (let i = 0; i < 20; i++) {
      const hash = verifyFairness(serverSeed, clientSeed, nonce + i);
      const index = Math.floor(hash * available.length / 100);
      const num = available.splice(index, 1)[0];
      drawn.push(num);

      setDrawnNumbers(prev => [...prev, num]);
      await new Promise(r => setTimeout(r, 100));
    }

    const matched = selectedNumbers.filter(n => drawn.includes(n));
    setMatchedNumbers(matched);

    const payout = currentBet * (PAYOUT_TABLE[matched.length] || 0);
    const win = payout > 0;

    const result = {
      win,
      amount: currentBet,
      multiplier: PAYOUT_TABLE[matched.length] || 0,
      payout,
      outcome: matched.length,
      hash: `${serverSeed}:${clientSeed}:${nonce}`,
      timestamp: Date.now(),
    };

    addToHistory(result);
    updateStats(result);
    incrementNonce();
    setShowResult(true);

    if (win) {
      toast.success(`Matched ${matched.length} numbers! +${formatSol(payout * 1e9)} SOL`);
    } else {
      toast(`Matched ${matched.length} numbers. No win this time.`);
    }

    setIsSpinning(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Keno</h1>
        <p className="text-gray-400">Pick up to 10 numbers and match the draw!</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Game */}
        <div className="lg:col-span-2 gradient-border rounded-2xl p-6 bg-solana-card">
          {/* Payout Table */}
          <div className="mb-6 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-gray-500 text-xs">
                  <th className="text-left py-2">Matches</th>
                  {Object.keys(PAYOUT_TABLE).filter(k => parseInt(k) >= 2).map(k => (
                    <th key={k} className="text-center py-2">{k}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="text-solana-green font-bold">
                  <td className="py-2 text-gray-400">Payout</td>
                  {Object.entries(PAYOUT_TABLE).filter(([k]) => parseInt(k) >= 2).map(([k, v]) => (
                    <td key={k} className="text-center py-2">{v}x</td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          {/* Number Grid */}
          <div className="grid grid-cols-8 gap-2 mb-6">
            {NUMBERS.map((num) => {
              const isSelected = selectedNumbers.includes(num);
              const isDrawn = drawnNumbers.includes(num);
              const isMatched = matchedNumbers.includes(num);

              return (
                <motion.button
                  key={num}
                  onClick={() => toggleNumber(num)}
                  disabled={isSpinning}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className={`aspect-square rounded-lg text-sm font-bold transition-all ${
                    isMatched
                      ? 'bg-solana-green text-black shadow-lg shadow-solana-green/50'
                      : isDrawn
                      ? 'bg-solana-purple/30 text-solana-purple border border-solana-purple/50'
                      : isSelected
                      ? 'bg-casino-gold text-black'
                      : 'bg-solana-dark text-gray-400 hover:bg-white/10 border border-solana-border'
                  }`}
                >
                  {num}
                </motion.button>
              );
            })}
          </div>

          {/* Selected Count */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm text-gray-500">
              Selected: <span className="text-white font-bold">{selectedNumbers.length}/10</span>
            </span>
            <div className="flex gap-2">
              <button
                onClick={autoPick}
                disabled={isSpinning}
                className="btn-secondary text-sm py-2 px-4"
              >
                <Sparkles className="w-4 h-4" />
                Auto Pick
              </button>
              <button
                onClick={clearSelection}
                disabled={isSpinning}
                className="btn-secondary text-sm py-2 px-4"
              >
                <RefreshCw className="w-4 h-4" />
                Clear
              </button>
            </div>
          </div>

          {/* Result */}
          <AnimatePresence>
            {showResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-4 p-4 bg-solana-dark rounded-lg border border-solana-border"
              >
                <div className="text-2xl font-bold text-white mb-1">
                  Matched {matchedNumbers.length} numbers!
                </div>
                {matchedNumbers.length >= 2 && (
                  <div className="text-solana-green font-bold text-xl">
                    +{formatSol(currentBet * (PAYOUT_TABLE[matchedNumbers.length] || 0) * 1e9)} SOL
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Controls */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-2 bg-solana-dark rounded-lg p-2 border border-solana-border">
              <button 
                onClick={() => setCurrentBet(Math.max(0.01, currentBet / 2))}
                className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
                disabled={isSpinning}
              >
                ½
              </button>
              <div className="flex-1 text-center">
                <div className="text-lg font-bold text-white">{currentBet} SOL</div>
              </div>
              <button 
                onClick={() => setCurrentBet(Math.min(100, currentBet * 2))}
                className="px-3 py-1 rounded text-sm bg-solana-card hover:bg-white/10"
                disabled={isSpinning}
              >
                2x
              </button>
            </div>

            <button
              onClick={draw}
              disabled={isSpinning || selectedNumbers.length < 2 || !connected}
              className="btn-primary flex-1 text-lg py-3 disabled:opacity-50"
            >
              {isSpinning ? (
                <span className="flex items-center justify-center gap-2">
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}>
                    <Grid3X3 className="w-5 h-5" />
                  </motion.div>
                  Drawing...
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <Play className="w-5 h-5" />
                  DRAW 20 NUMBERS
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-4">
          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">How to Play</h3>
            <ol className="space-y-2 text-sm text-gray-500 list-decimal list-inside">
              <li>Select 2-10 numbers from the grid</li>
              <li>Set your bet amount</li>
              <li>Click "Draw 20 Numbers"</li>
              <li>Match as many as possible to win!</li>
            </ol>
          </div>

          <div className="gradient-border rounded-xl p-4 bg-solana-card">
            <h3 className="text-sm font-semibold text-gray-400 mb-3">Your Selection</h3>
            <div className="flex flex-wrap gap-2">
              {selectedNumbers.length === 0 ? (
                <span className="text-sm text-gray-600">No numbers selected</span>
              ) : (
                selectedNumbers.map(num => (
                  <span key={num} className="bg-casino-gold text-black text-sm font-bold px-2 py-1 rounded">
                    {num}
                  </span>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
