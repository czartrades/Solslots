"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { verifyFairness, formatSol, sleep } from "@/lib/utils";
import { Play, Minus, Plus, History, Sparkles } from "lucide-react";
import toast from "react-hot-toast";
import confetti from "canvas-confetti";

const SYMBOLS = [
  { id: "7", value: 50, emoji: "7️⃣", weight: 1 },
  { id: "diamond", value: 25, emoji: "💎", weight: 2 },
  { id: "bar", value: 15, emoji: "🎰", weight: 3 },
  { id: "bell", value: 10, emoji: "🔔", weight: 4 },
  { id: "cherry", value: 5, emoji: "🍒", weight: 5 },
  { id: "lemon", value: 3, emoji: "🍋", weight: 6 },
  { id: "grape", value: 2, emoji: "🍇", weight: 7 },
];

const REELS = 5;
const ROWS = 3;

export function SlotsGame() {
  const { connected, balance } = useWallet();
  const { 
    currentBet, setCurrentBet, 
    isSpinning, setIsSpinning,
    addToHistory, updateStats,
    serverSeed, clientSeed, nonce, 
    incrementNonce, setSeeds
  } = useGameStore();

  const [reels, setReels] = useState<string[][]>(
    Array(REELS).fill(Array(ROWS).fill("🍋"))
  );
  const [winAmount, setWinAmount] = useState(0);
  const [showWin, setShowWin] = useState(false);
  const [spinningReels, setSpinningReels] = useState<boolean[]>(Array(REELS).fill(false));

  useEffect(() => {
    if (!serverSeed) {
      setSeeds(
        "server_seed_" + Math.random().toString(36).substring(7),
        "client_seed_" + Math.random().toString(36).substring(7)
      );
    }
  }, []);

  const getRandomSymbol = useCallback((seed: string, reelIndex: number, rowIndex: number) => {
    const hash = verifyFairness(seed, clientSeed, nonce + reelIndex * 10 + rowIndex);
    const totalWeight = SYMBOLS.reduce((sum, s) => sum + s.weight, 0);
    let random = hash * totalWeight;

    for (const symbol of SYMBOLS) {
      random -= symbol.weight;
      if (random <= 0) return symbol;
    }
    return SYMBOLS[SYMBOLS.length - 1];
  }, [clientSeed, nonce]);

  const calculateWin = (result: string[][]) => {
    let totalWin = 0;
    const paylines = [
      [0, 0, 0, 0, 0], // Top
      [1, 1, 1, 1, 1], // Middle
      [2, 2, 2, 2, 2], // Bottom
      [0, 1, 2, 1, 0], // V shape
      [2, 1, 0, 1, 2], // Inverted V
    ];

    for (const line of paylines) {
      const symbols = line.map((row, col) => result[col][row]);
      const first = symbols[0];
      let matchCount = 1;

      for (let i = 1; i < symbols.length; i++) {
        if (symbols[i] === first) matchCount++;
        else break;
      }

      if (matchCount >= 3) {
        const symbolData = SYMBOLS.find(s => s.emoji === first);
        if (symbolData) {
          const multiplier = matchCount === 5 ? symbolData.value : matchCount === 4 ? symbolData.value * 0.5 : symbolData.value * 0.2;
          totalWin += currentBet * multiplier;
        }
      }
    }
    return totalWin;
  };

  const spin = async () => {
    if (!connected) {
      toast.error("Connect your wallet first!");
      return;
    }
    if (balance < currentBet) {
      toast.error("Insufficient SOL balance!");
      return;
    }
    if (isSpinning) return;

    setIsSpinning(true);
    setShowWin(false);
    setWinAmount(0);

    // Start spinning animation
    const newSpinning = Array(REELS).fill(true);
    setSpinningReels(newSpinning);

    // Generate result
    const newReels: string[][] = [];
    for (let i = 0; i < REELS; i++) {
      const reel: string[] = [];
      for (let j = 0; j < ROWS; j++) {
        const symbol = getRandomSymbol(serverSeed, i, j);
        reel.push(symbol.emoji);
      }
      newReels.push(reel);
    }

    // Stop reels one by one with delay
    for (let i = 0; i < REELS; i++) {
      await sleep(300 + i * 200);
      setSpinningReels(prev => {
        const updated = [...prev];
        updated[i] = false;
        return updated;
      });

      // Show partial result
      setReels(prev => {
        const updated = [...prev];
        updated[i] = newReels[i];
        return updated;
      });
    }

    await sleep(200);

    const win = calculateWin(newReels);
    const winMultiplier = win > 0 ? win / currentBet : 0;

    const result = {
      win: win > 0,
      amount: currentBet,
      multiplier: winMultiplier,
      payout: win,
      outcome: winMultiplier,
      hash: `${serverSeed}:${clientSeed}:${nonce}`,
      timestamp: Date.now(),
    };

    addToHistory(result);
    updateStats(result);
    incrementNonce();

    if (win > 0) {
      setWinAmount(win);
      setShowWin(true);
      toast.success(`You won ${formatSol(win * 1e9)} SOL! (${winMultiplier.toFixed(2)}x)`);

      if (winMultiplier >= 10) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#14F195', '#9945FF', '#FFD700']
        });
      }
    } else {
      toast("Better luck next time!", { icon: '🎰' });
    }

    setIsSpinning(false);
  };

  const adjustBet = (delta: number) => {
    const newBet = Math.max(0.01, Math.min(100, currentBet + delta));
    setCurrentBet(Math.round(newBet * 100) / 100);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Solana Slots</h1>
        <p className="text-gray-400">5-reel provably fair slot machine</p>
      </div>

      {/* Game Container */}
      <div className="gradient-border rounded-2xl p-6 bg-solana-card">
        {/* Win Display */}
        <AnimatePresence>
          {showWin && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              className="text-center mb-6"
            >
              <div className="inline-flex items-center gap-2 bg-casino-gold/20 border border-casino-gold/50 rounded-full px-6 py-3">
                <Sparkles className="w-5 h-5 text-casino-gold" />
                <span className="text-xl font-bold text-casino-gold">
                  +{formatSol(winAmount * 1e9)} SOL
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Slot Machine */}
        <div className="relative bg-black/50 rounded-xl p-4 mb-6 border border-solana-border">
          <div className="grid grid-cols-5 gap-2">
            {reels.map((reel, reelIndex) => (
              <div key={reelIndex} className="relative overflow-hidden rounded-lg bg-solana-dark border border-solana-border">
                <div className="flex flex-col">
                  {Array(ROWS).fill(0).map((_, rowIndex) => (
                    <motion.div
                      key={rowIndex}
                      className="h-20 flex items-center justify-center text-4xl"
                      animate={spinningReels[reelIndex] ? {
                        y: [0, -20, 0, -40, 0],
                      } : {}}
                      transition={spinningReels[reelIndex] ? {
                        duration: 0.1,
                        repeat: Infinity,
                        ease: "linear"
                      } : {}}
                    >
                      {spinningReels[reelIndex] ? (
                        <span className="opacity-50">❓</span>
                      ) : (
                        <motion.span
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: "spring", stiffness: 200 }}
                        >
                          {reel[rowIndex]}
                        </motion.span>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Payline indicators */}
          <div className="absolute left-0 top-1/3 w-2 h-1/3 border-l-2 border-solana-green/30 rounded-l" />
          <div className="absolute right-0 top-1/3 w-2 h-1/3 border-r-2 border-solana-green/30 rounded-r" />
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
          {/* Bet Controls */}
          <div className="flex items-center gap-3 bg-solana-dark rounded-lg p-2 border border-solana-border">
            <button 
              onClick={() => adjustBet(-0.1)}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              disabled={isSpinning}
            >
              <Minus className="w-4 h-4" />
            </button>
            <div className="text-center min-w-[100px]">
              <div className="text-sm text-gray-500">Bet Amount</div>
              <div className="text-lg font-bold text-white">{currentBet} SOL</div>
            </div>
            <button 
              onClick={() => adjustBet(0.1)}
              className="p-2 rounded-lg hover:bg-white/10 transition-colors"
              disabled={isSpinning}
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Bets */}
          <div className="flex gap-2">
            {[0.1, 0.5, 1, 5].map((amount) => (
              <button
                key={amount}
                onClick={() => setCurrentBet(amount)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentBet === amount 
                    ? 'bg-solana-purple text-white' 
                    : 'bg-solana-dark text-gray-400 hover:text-white border border-solana-border'
                }`}
                disabled={isSpinning}
              >
                {amount} SOL
              </button>
            ))}
          </div>

          {/* Spin Button */}
          <button
            onClick={spin}
            disabled={isSpinning || !connected}
            className="btn-primary flex-1 sm:flex-none text-lg px-12 py-4 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSpinning ? (
              <span className="flex items-center gap-2">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity }}>
                  <Sparkles className="w-5 h-5" />
                </motion.div>
                Spinning...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                SPIN
              </span>
            )}
          </button>
        </div>

        {/* Provably Fair Info */}
        <div className="bg-solana-dark rounded-lg p-4 border border-solana-border">
          <div className="flex items-center gap-2 mb-2">
            <History className="w-4 h-4 text-solana-green" />
            <span className="text-sm font-medium text-solana-green">Provably Fair</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono text-gray-500">
            <div className="truncate">Server: {serverSeed.slice(0, 20)}...</div>
            <div className="truncate">Client: {clientSeed.slice(0, 20)}...</div>
            <div>Nonce: {nonce}</div>
          </div>
        </div>
      </div>

      {/* Symbol Payouts */}
      <div className="mt-6 gradient-border rounded-xl p-4">
        <h3 className="text-sm font-semibold text-gray-400 mb-3">Payout Table (5 of a kind)</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {SYMBOLS.map((symbol) => (
            <div key={symbol.id} className="flex items-center justify-between bg-solana-dark rounded-lg px-3 py-2">
              <span className="text-xl">{symbol.emoji}</span>
              <span className="text-sm font-mono text-solana-green">{symbol.value}x</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
