"use client";

import { motion } from "framer-motion";
import { Crown, Coins, Gift, Zap, Shield, Star, TrendingUp } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";

const TIERS = [
  { name: "Bronze", wagered: 0, rakeback: 5, color: "from-amber-800 to-amber-950", icon: Star },
  { name: "Silver", wagered: 10, rakeback: 7, color: "from-gray-400 to-gray-600", icon: Star },
  { name: "Gold", wagered: 50, rakeback: 10, color: "from-yellow-500 to-yellow-700", icon: Crown },
  { name: "Platinum", wagered: 250, rakeback: 12, color: "from-cyan-400 to-blue-600", icon: Crown },
  { name: "Diamond", wagered: 1000, rakeback: 15, color: "from-purple-400 to-pink-600", icon: Crown },
];

const BENEFITS = [
  { icon: Coins, title: "Rakeback", desc: "Get up to 15% of your losses back daily" },
  { icon: Gift, title: "Weekly Bonuses", desc: "Exclusive reload bonuses every week" },
  { icon: Zap, title: "Faster Withdrawals", desc: "Priority processing for VIP members" },
  { icon: Shield, title: "Personal Support", desc: "Dedicated VIP support agent" },
  { icon: TrendingUp, title: "Higher Limits", desc: "Increased bet and withdrawal limits" },
  { icon: Star, title: "Exclusive Games", desc: "Access to VIP-only tournaments" },
];

export function VipStatus() {
  const { connected, balance } = useWallet();
  const currentWagered = 45; // Mock data
  const currentTier = TIERS.findIndex(t => currentWagered < t.wagered) - 1;
  const activeTier = currentTier >= 0 ? TIERS[currentTier] : TIERS[0];
  const nextTier = TIERS[currentTier + 1];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold gradient-text mb-4">VIP Program</h1>
        <p className="text-xl text-gray-400">Unlock exclusive rewards as you play</p>
      </div>

      {/* Current Status */}
      {connected && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="gradient-border rounded-2xl p-8 bg-solana-card mb-12"
        >
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${activeTier.color} flex items-center justify-center`}>
              <activeTier.icon className="w-12 h-12 text-white" />
            </div>
            <div className="text-center md:text-left flex-1">
              <h2 className="text-2xl font-bold text-white mb-1">{activeTier.name} Tier</h2>
              <p className="text-gray-400 mb-2">Current Rakeback: <span className="text-solana-green font-bold">{activeTier.rakeback}%</span></p>

              {nextTier && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-500">Progress to {nextTier.name}</span>
                    <span className="text-white font-mono">{currentWagered} / {nextTier.wagered} SOL</span>
                  </div>
                  <div className="h-3 bg-solana-dark rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(currentWagered / nextTier.wagered) * 100}%` }}
                      className={`h-full bg-gradient-to-r ${activeTier.color}`}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}

      {/* Tier Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
        {TIERS.map((tier, index) => (
          <motion.div
            key={tier.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className={`gradient-border rounded-xl p-4 text-center ${
              index === currentTier ? 'ring-2 ring-solana-green' : ''
            }`}
          >
            <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${tier.color} flex items-center justify-center`}>
              <tier.icon className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-bold text-white mb-1">{tier.name}</h3>
            <div className="text-xs text-gray-500 mb-2">{tier.wagered} SOL wagered</div>
            <div className="text-lg font-bold text-solana-green">{tier.rakeback}%</div>
            <div className="text-xs text-gray-500">Rakeback</div>
          </motion.div>
        ))}
      </div>

      {/* Benefits */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-6 text-center">VIP Benefits</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {BENEFITS.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="gradient-border rounded-xl p-6"
            >
              <benefit.icon className="w-8 h-8 text-solana-purple mb-3" />
              <h3 className="font-bold text-white mb-1">{benefit.title}</h3>
              <p className="text-sm text-gray-500">{benefit.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
