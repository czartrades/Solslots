"use client";

import Link from "next/link";
import { Coins, Twitter, MessageCircle, Github, Shield, FileText, HelpCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-solana-border bg-solana-dark mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-solana-purple to-solana-green flex items-center justify-center">
                <Coins className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold gradient-text">SolSlots.io</span>
            </Link>
            <p className="text-sm text-gray-500 leading-relaxed">
              The fastest provably fair casino on Solana. Instant deposits, instant withdrawals, 1% house edge.
            </p>
            <div className="flex items-center gap-3">
              <a href="https://twitter.com/solslots" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-solana-card hover:bg-solana-purple/20 transition-colors">
                <Twitter className="w-4 h-4 text-gray-400" />
              </a>
              <a href="https://discord.gg/solslots" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-solana-card hover:bg-solana-purple/20 transition-colors">
                <MessageCircle className="w-4 h-4 text-gray-400" />
              </a>
              <a href="https://github.com/solslots" target="_blank" rel="noopener noreferrer" className="p-2 rounded-lg bg-solana-card hover:bg-solana-purple/20 transition-colors">
                <Github className="w-4 h-4 text-gray-400" />
              </a>
            </div>
          </div>

          {/* Games */}
          <div>
            <h3 className="font-semibold text-white mb-4">Games</h3>
            <ul className="space-y-2">
              {['Slots', 'Dice', 'Crash', 'Plinko', 'Keno', 'Roulette'].map((game) => (
                <li key={game}>
                  <Link href={`/games/${game.toLowerCase()}`} className="text-sm text-gray-500 hover:text-solana-green transition-colors">
                    {game}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-white mb-4">Support</h3>
            <ul className="space-y-2">
              {[
                { label: 'Help Center', icon: HelpCircle, href: '/help' },
                { label: 'Provably Fair', icon: Shield, href: '/provably-fair' },
                { label: 'Terms of Service', icon: FileText, href: '/terms' },
                { label: 'Privacy Policy', icon: FileText, href: '/privacy' },
              ].map((item) => (
                <li key={item.label}>
                  <Link href={item.href} className="flex items-center gap-2 text-sm text-gray-500 hover:text-solana-green transition-colors">
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Stats */}
          <div>
            <h3 className="font-semibold text-white mb-4">Live Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Total Wagered</span>
                <span className="text-solana-green font-mono">2,847,293 SOL</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Players Online</span>
                <span className="text-solana-purple font-mono">1,247</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">House Edge</span>
                <span className="text-casino-gold font-mono">1.0%</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Avg Payout Time</span>
                <span className="text-white font-mono">&lt;2s</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-solana-border mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-600">
            © 2026 SolSlots.io. All rights reserved. 18+ Only. Gamble responsibly.
          </p>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Shield className="w-4 h-4 text-solana-green" />
              RNG Certified
            </span>
            <span className="flex items-center gap-1">
              <Shield className="w-4 h-4 text-solana-purple" />
              Audited by CertiK
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
