"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Zap, Shield, Coins, TrendingUp } from "lucide-react";

export function Hero() {
  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-solana-purple/20 via-transparent to-transparent" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-solana-green/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-solana-purple/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 bg-solana-green/10 border border-solana-green/30 rounded-full px-4 py-1.5 mb-6">
              <Zap className="w-4 h-4 text-solana-green" />
              <span className="text-sm font-medium text-solana-green">Now Live on Solana Mainnet</span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold tracking-tight mb-6"
          >
            The Future of{' '}
            <span className="gradient-text">Web3 Gambling</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-gray-400 mb-10 leading-relaxed"
          >
            Instant deposits. Instant withdrawals. Provably fair games with 1% house edge.
            The fastest casino experience on Solana.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link href="/games" className="btn-primary text-lg px-8 py-4 flex items-center gap-2">
              Start Playing
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/provably-fair" className="btn-secondary text-lg px-8 py-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Verify Fairness
            </Link>
          </motion.div>

          {/* Stats Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            {[
              { icon: Coins, label: "Total Wagered", value: "2.8M SOL", color: "text-solana-green" },
              { icon: TrendingUp, label: "Biggest Win", value: "4,200x", color: "text-casino-gold" },
              { icon: Zap, label: "Avg Speed", value: "<2s", color: "text-solana-purple" },
              { icon: Shield, label: "House Edge", value: "1.0%", color: "text-white" },
            ].map((stat, i) => (
              <div key={i} className="glass-panel rounded-xl p-4 text-center">
                <stat.icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
