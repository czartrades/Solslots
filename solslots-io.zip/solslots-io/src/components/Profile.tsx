"use client";

import { motion } from "framer-motion";
import { useWallet } from "@/hooks/useWallet";
import { useGameStore } from "@/hooks/useGameStore";
import { formatSol, shortenAddress } from "@/lib/utils";
import { User, TrendingUp, TrendingDown, Gamepad2, Clock, Crown, Wallet } from "lucide-react";

export function Profile() {
  const { connected, address, shortAddress, balance } = useWallet();
  const { userStats, betHistory } = useGameStore();

  if (!connected) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <Wallet className="w-16 h-16 text-solana-purple mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-white mb-4">Connect Your Wallet</h1>
        <p className="text-gray-400">Connect your Solana wallet to view your profile and stats</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold gradient-text mb-2">Your Profile</h1>
      </div>

      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="gradient-border rounded-2xl p-6 bg-solana-card mb-8"
      >
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-solana-purple to-solana-green flex items-center justify-center">
            <User className="w-10 h-10 text-white" />
          </div>
          <div className="text-center md:text-left flex-1">
            <h2 className="text-xl font-bold text-white">{shortAddress}</h2>
            <p className="text-sm text-gray-500 font-mono">{address}</p>
            <div className="flex items-center gap-4 mt-2">
              <span className="text-sm text-solana-green font-bold">{formatSol(balance * 1e9)} SOL</span>
              <span className="flex items-center gap-1 text-sm text-casino-gold">
                <Crown className="w-4 h-4" />
                Bronze Tier
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { icon: Gamepad2, label: "Total Bets", value: userStats.totalBets, color: "text-solana-purple" },
          { icon: TrendingUp, label: "Total Wagered", value: `${formatSol(userStats.totalWagered * 1e9)} SOL`, color: "text-solana-green" },
          { icon: TrendingDown, label: "Profit/Loss", value: `${userStats.profit >= 0 ? '+' : ''}${formatSol(userStats.profit * 1e9)} SOL`, color: userStats.profit >= 0 ? "text-solana-green" : "text-casino-red" },
          { icon: TrendingUp, label: "Best Multiplier", value: `${userStats.bestMultiplier.toFixed(2)}x`, color: "text-casino-gold" },
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="gradient-border rounded-xl p-4 text-center"
          >
            <stat.icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
            <div className="text-lg font-bold text-white">{stat.value}</div>
            <div className="text-xs text-gray-500">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Bet History */}
      <div className="gradient-border rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-solana-border">
          <Clock className="w-4 h-4 text-solana-green" />
          <span className="text-sm font-semibold text-white">Recent Bets</span>
        </div>

        {betHistory.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            No bets yet. Start playing to see your history!
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-solana-dark">
              <tr>
                <th className="px-4 py-2 text-left text-xs text-gray-500">Time</th>
                <th className="px-4 py-2 text-right text-xs text-gray-500">Bet</th>
                <th className="px-4 py-2 text-right text-xs text-gray-500">Multiplier</th>
                <th className="px-4 py-2 text-right text-xs text-gray-500">Payout</th>
                <th className="px-4 py-2 text-center text-xs text-gray-500">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-solana-border">
              {betHistory.slice(0, 20).map((bet, i) => (
                <tr key={i} className="hover:bg-white/5">
                  <td className="px-4 py-3 text-sm text-gray-400">
                    {new Date(bet.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="px-4 py-3 text-sm text-right text-gray-400">
                    {formatSol(bet.amount * 1e9)} SOL
                  </td>
                  <td className="px-4 py-3 text-sm text-right text-white">
                    {bet.multiplier.toFixed(2)}x
                  </td>
                  <td className={`px-4 py-3 text-sm text-right font-bold ${
                    bet.win ? 'text-solana-green' : 'text-casino-red'
                  }`}>
                    {bet.win ? '+' : ''}{formatSol(bet.payout * 1e9)} SOL
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-block px-2 py-1 rounded text-xs font-bold ${
                      bet.win ? 'bg-solana-green/20 text-solana-green' : 'bg-casino-red/20 text-casino-red'
                    }`}>
                      {bet.win ? 'WIN' : 'LOSS'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
