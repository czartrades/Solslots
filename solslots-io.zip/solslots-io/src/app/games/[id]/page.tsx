"use client";

import { useParams } from "next/navigation";
import { SlotsGame } from "@/components/SlotsGame";
import { DiceGame } from "@/components/DiceGame";
import { CrashGame } from "@/components/CrashGame";
import { PlinkoGame } from "@/components/PlinkoGame";
import { KenoGame } from "@/components/KenoGame";
import { BetHistory } from "@/components/BetHistory";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

const GAME_COMPONENTS: Record<string, React.ComponentType> = {
  slots: SlotsGame,
  dice: DiceGame,
  crash: CrashGame,
  plinko: PlinkoGame,
  keno: KenoGame,
};

export default function GamePage() {
  const params = useParams();
  const gameId = params.id as string;
  const GameComponent = GAME_COMPONENTS[gameId];

  if (!GameComponent) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold text-white mb-4">Game Not Found</h1>
        <p className="text-gray-400 mb-6">This game doesn&apos;t exist or is coming soon.</p>
        <Link href="/games" className="btn-primary inline-flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Games
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <GameComponent />
        </div>
        <div className="hidden lg:block">
          <BetHistory />
        </div>
      </div>
    </div>
  );
}
