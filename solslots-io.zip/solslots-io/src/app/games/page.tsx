import { GameGrid } from "@/components/GameGrid";

export default function GamesPage() {
  return <GameGrid />;
}
