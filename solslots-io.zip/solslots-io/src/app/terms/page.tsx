export default function TermsPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold gradient-text mb-8">Terms of Service</h1>

      <div className="space-y-6 text-gray-400">
        <section>
          <h2 className="text-xl font-bold text-white mb-3">1. Acceptance of Terms</h2>
          <p>By accessing and using SolSlots.io, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">2. Eligibility</h2>
          <p>You must be at least 18 years old to use SolSlots.io. By using our platform, you represent and warrant that you meet this age requirement.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">3. Cryptocurrency Risks</h2>
          <p>Cryptocurrency gambling involves significant risk. The value of cryptocurrencies can be volatile. You acknowledge that you are solely responsible for your gambling decisions.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">4. Provably Fair System</h2>
          <p>All games on SolSlots.io use a provably fair system. Game outcomes are determined by a combination of server and client seeds. You can verify the fairness of any game outcome.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">5. Prohibited Jurisdictions</h2>
          <p>Users from certain jurisdictions may be prohibited from using our platform. It is your responsibility to ensure that online gambling is legal in your jurisdiction.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">6. Responsible Gambling</h2>
          <p>We encourage responsible gambling. If you feel you have a gambling problem, please seek help. We provide self-exclusion options and deposit limits.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">7. Modifications</h2>
          <p>We reserve the right to modify these terms at any time. Continued use of the platform after changes constitutes acceptance of the new terms.</p>
        </section>
      </div>
    </div>
  );
}
