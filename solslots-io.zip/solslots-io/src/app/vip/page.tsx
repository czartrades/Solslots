import { VipStatus } from "@/components/VipStatus";

export default function VipPage() {
  return <VipStatus />;
}
