import { ProvablyFair } from "@/components/ProvablyFair";

export default function ProvablyFairPage() {
  return <ProvablyFair />;
}
