import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { SolanaProvider } from "@/components/SolanaProvider";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Toaster } from "react-hot-toast";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "SolSlots.io | Web3 Casino on Solana",
  description: "The fastest provably fair casino on Solana. Instant deposits, instant withdrawals, 1% house edge. Play slots, dice, crash, plinko and more.",
  keywords: ["solana casino", "web3 gambling", "crypto casino", "provably fair", "solslots", "defi casino"],
  openGraph: {
    title: "SolSlots.io - Web3 Casino on Solana",
    description: "Instant crypto gambling with provably fair games",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="antialiased">
        <SolanaProvider>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <Toaster 
            position="top-right"
            toastOptions={{
              style: {
                background: '#141414',
                border: '1px solid #2A2A2A',
                color: '#fff',
              },
            }}
          />
        </SolanaProvider>
      </body>
    </html>
  );
}
