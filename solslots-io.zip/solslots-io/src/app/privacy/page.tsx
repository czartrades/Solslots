export default function PrivacyPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold gradient-text mb-8">Privacy Policy</h1>

      <div className="space-y-6 text-gray-400">
        <section>
          <h2 className="text-xl font-bold text-white mb-3">1. Information We Collect</h2>
          <p>We collect minimal information necessary to operate the platform. This includes your Solana wallet address, betting history, and game preferences. We do not collect personal identification information.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">2. Blockchain Data</h2>
          <p>All transactions on SolSlots.io are recorded on the Solana blockchain. This data is public and immutable by design. Your wallet address and transaction history are visible on the blockchain.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">3. Cookies</h2>
          <p>We use minimal cookies to improve your experience. These include session cookies for wallet connection state and preference cookies for game settings.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">4. Data Security</h2>
          <p>We implement industry-standard security measures. However, no online system is completely secure. You are responsible for securing your wallet and private keys.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">5. Third Parties</h2>
          <p>We do not sell or share your data with third parties. We may use third-party services for analytics and wallet connectivity, subject to their privacy policies.</p>
        </section>

        <section>
          <h2 className="text-xl font-bold text-white mb-3">6. Changes to Policy</h2>
          <p>We may update this privacy policy from time to time. We will notify users of significant changes through the platform.</p>
        </section>
      </div>
    </div>
  );
}
