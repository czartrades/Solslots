import { Hero } from "@/components/Hero";
import { GameGrid } from "@/components/GameGrid";
import { LiveStats } from "@/components/LiveStats";
import { BetHistory } from "@/components/BetHistory";
import { motion } from "framer-motion";
import { GameCard } from "@/components/GameCard";
import { Game } from "@/types";
import { ArrowRight, Sparkles, Zap } from "lucide-react";
import Link from "next/link";

const FEATURED_GAMES: Game[] = [
  { id: "slots", name: "Solana Slots", category: "originals", image: "/images/games/slots.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 100, isLive: true, players: 234 },
  { id: "crash", name: "Crash", category: "originals", image: "/images/games/crash.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 1000, isLive: true, players: 89 },
  { id: "dice", name: "Dice", category: "originals", image: "/images/games/dice.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 500, isLive: true, players: 156 },
  { id: "plinko", name: "Plinko", category: "originals", image: "/images/games/plinko.jpg", houseEdge: 1.0, minBet: 0.01, maxBet: 100, isLive: true, players: 67 },
];

export default function Home() {
  return (
    <div>
      <Hero />
      <LiveStats />

      {/* Featured Games */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Featured Games</h2>
            <p className="text-gray-500">Our most popular provably fair games</p>
          </div>
          <Link href="/games" className="flex items-center gap-1 text-sm text-solana-green hover:text-solana-purple transition-colors">
            View All
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {FEATURED_GAMES.map((game, index) => (
            <GameCard key={game.id} game={game} index={index} />
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold gradient-text mb-4">Why SolSlots?</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">The most advanced Web3 casino experience built on Solana</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Zap, title: "Instant Transactions", desc: "Deposits and withdrawals in under 2 seconds with Solana's 50k TPS" },
            { icon: Sparkles, title: "Provably Fair", desc: "Every game outcome is verifiable using cryptographic hashing" },
            { icon: Zap, title: "Lowest House Edge", desc: "Just 1% on all original games. Keep more of your winnings" },
          ].map((feature, index) => (
            <div key={index} className="gradient-border rounded-xl p-6 text-center">
              <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-solana-purple/20 to-solana-green/20 flex items-center justify-center">
                <feature.icon className="w-7 h-7 text-solana-green" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Live Activity */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-6">Recent Big Wins</h2>
            <div className="gradient-border rounded-xl p-6 bg-solana-card">
              <div className="space-y-4">
                {[
                  { user: "WhaleKing", game: "Crash", mult: 420, win: 2100, time: "2 min ago" },
                  { user: "SolMaster", game: "Plinko", mult: 130, win: 650, time: "5 min ago" },
                  { user: "CryptoQueen", game: "Slots", mult: 1000, win: 500, time: "12 min ago" },
                  { user: "DegenLife", game: "Dice", mult: 49.5, win: 247.5, time: "18 min ago" },
                  { user: "MoonBoi", game: "Crash", mult: 89, win: 445, time: "25 min ago" },
                ].map((win, i) => (
                  <div key={i} className="flex items-center justify-between py-3 border-b border-solana-border last:border-0">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-solana-purple to-solana-green flex items-center justify-center text-white font-bold">
                        {win.user[0]}
                      </div>
                      <div>
                        <div className="font-medium text-white">{win.user}</div>
                        <div className="text-xs text-gray-500">{win.game} • {win.time}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-casino-gold font-bold">+{win.win} SOL</div>
                      <div className="text-xs text-solana-green">{win.mult}x multiplier</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Live Activity</h2>
            <BetHistory />
          </div>
        </div>
      </section>
    </div>
  );
}
