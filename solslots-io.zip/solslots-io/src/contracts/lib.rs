use anchor_lang::prelude::*;
use anchor_lang::solana_program::hash::hash;

declare_id!("Slot111111111111111111111111111111111111111");

#[program]
pub mod solslots {
    use super::*;

    pub fn initialize_house(ctx: Context<InitializeHouse>) -> Result<()> {
        let house = &mut ctx.accounts.house;
        house.authority = ctx.accounts.authority.key();
        house.balance = 0;
        house.total_wagered = 0;
        house.total_paid_out = 0;
        house.house_edge = 100; // 1.00% = 100 basis points
        house.bump = ctx.bumps.house;
        Ok(())
    }

    pub fn place_bet(
        ctx: Context<PlaceBet>,
        amount: u64,
        game_type: u8,
        client_seed: String,
    ) -> Result<()> {
        let bet = &mut ctx.accounts.bet;
        let house = &mut ctx.accounts.house;
        let player = &ctx.accounts.player;

        require!(amount >= 10_000_000, ErrorCode::InvalidBetAmount); // 0.01 SOL min
        require!(amount <= 1_000_000_000_000, ErrorCode::InvalidBetAmount); // 1000 SOL max

        bet.player = player.key();
        bet.amount = amount;
        bet.game_type = game_type;
        bet.client_seed = client_seed;
        bet.server_seed_hash = "pending".to_string();
        bet.nonce = house.total_wagered;
        bet.status = 0; // Pending
        bet.timestamp = Clock::get()?.unix_timestamp;

        house.total_wagered += amount;

        // Transfer SOL from player to house escrow
        let cpi_context = CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            anchor_lang::system_program::Transfer {
                from: player.to_account_info(),
                to: house.to_account_info(),
            },
        );
        anchor_lang::system_program::transfer(cpi_context, amount)?;

        Ok(())
    }

    pub fn settle_bet(
        ctx: Context<SettleBet>,
        server_seed: String,
        outcome: u64,
        payout: u64,
    ) -> Result<()> {
        let bet = &mut ctx.accounts.bet;
        let house = &mut ctx.accounts.house;

        require!(bet.status == 0, ErrorCode::BetAlreadySettled);
        require!(payout <= house.balance, ErrorCode::InsufficientBalance);

        // Verify outcome using seeds
        let combined = format!("{}:{}:{}", server_seed, bet.client_seed, bet.nonce);
        let hash_result = hash(combined.as_bytes());
        let expected_outcome = u64::from_le_bytes(hash_result.to_bytes()[0..8].try_into().unwrap()) % 10000;

        require!(expected_outcome == outcome, ErrorCode::InvalidOutcome);

        bet.status = 1; // Settled
        bet.server_seed_hash = server_seed;

        if payout > 0 {
            house.total_paid_out += payout;
            house.balance -= payout;

            // Transfer payout to player
            **house.to_account_info().try_borrow_mut_lamports()? -= payout;
            **ctx.accounts.player.to_account_info().try_borrow_mut_lamports()? += payout;
        }

        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializeHouse<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 8 + 8 + 8 + 2 + 1,
        seeds = [b"house"],
        bump
    )]
    pub house: Account<'info, House>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct PlaceBet<'info> {
    #[account(mut, seeds = [b"house"], bump = house.bump)]
    pub house: Account<'info, House>,
    #[account(mut)]
    pub player: Signer<'info>,
    #[account(
        init,
        payer = player,
        space = 8 + 32 + 8 + 1 + 64 + 64 + 8 + 1 + 8,
        seeds = [b"bet", player.key().as_ref(), &house.total_wagered.to_le_bytes()],
        bump
    )]
    pub bet: Account<'info, Bet>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SettleBet<'info> {
    #[account(mut, seeds = [b"house"], bump = house.bump)]
    pub house: Account<'info, House>,
    #[account(mut, constraint = bet.player == player.key())]
    pub bet: Account<'info, Bet>,
    #[account(mut)]
    pub player: AccountInfo<'info>,
    pub authority: Signer<'info>,
}

#[account]
pub struct House {
    pub authority: Pubkey,
    pub balance: u64,
    pub total_wagered: u64,
    pub total_paid_out: u64,
    pub house_edge: u16,
    pub bump: u8,
}

#[account]
pub struct Bet {
    pub player: Pubkey,
    pub amount: u64,
    pub game_type: u8,
    pub client_seed: String,
    pub server_seed_hash: String,
    pub nonce: u64,
    pub status: u8,
    pub timestamp: i64,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Insufficient house balance")]
    InsufficientBalance,
    #[msg("Bet amount out of range")]
    InvalidBetAmount,
    #[msg("Bet already settled")]
    BetAlreadySettled,
    #[msg("Unauthorized access")]
    Unauthorized,
    #[msg("Invalid outcome")]
    InvalidOutcome,
}