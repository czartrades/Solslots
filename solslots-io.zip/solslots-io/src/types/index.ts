export interface Game {
  id: string;
  name: string;
  category: 'originals' | 'slots' | 'live' | 'table';
  image: string;
  houseEdge: number;
  minBet: number;
  maxBet: number;
  isLive: boolean;
  players?: number;
}

export interface BetResult {
  win: boolean;
  amount: number;
  multiplier: number;
  payout: number;
  outcome: number;
  hash: string;
  timestamp: number;
}

export interface UserStats {
  totalWagered: number;
  totalWon: number;
  totalBets: number;
  winRate: number;
  bestMultiplier: number;
  profit: number;
}

export interface SlotSymbol {
  id: string;
  value: number;
  image: string;
  weight: number;
}

export interface PlinkoConfig {
  rows: number;
  risk: 'low' | 'medium' | 'high';
  multipliers: number[];
}

export interface CrashRound {
  id: string;
  crashPoint: number;
  startTime: number;
  endTime?: number;
  bets: CrashBet[];
}

export interface CrashBet {
  user: string;
  amount: number;
  autoCashout?: number;
  cashedOut?: number;
  profit?: number;
}

export interface LeaderboardEntry {
  rank: number;
  address: string;
  username: string;
  wagered: number;
  profit: number;
  multiplier: number;
  avatar?: string;
}
