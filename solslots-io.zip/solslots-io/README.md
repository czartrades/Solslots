# SolSlots.io - Web3 Casino on Solana

A fully functional, provably fair Web3 casino built on Solana.

## Features

- **4 Original Games**: Slots, Dice, Crash, Plinko
- **Provably Fair**: Cryptographically verifiable game outcomes
- **Instant Transactions**: Sub-second deposits/withdrawals on Solana
- **1% House Edge**: Lowest in the industry
- **Wallet Integration**: Phantom, Solflare, Torus, Ledger
- **Live Stats**: Real-time wager tracking and leaderboards

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Blockchain**: Solana (Mainnet/Devnet)
- **Smart Contracts**: Rust + Anchor Framework (coming soon)
- **State**: Zustand
- **Animation**: Framer Motion

## Getting Started

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build
```

## Game Routes

- `/` - Home with featured games
- `/games` - All games grid
- `/games/slots` - Slot machine
- `/games/dice` - Dice game
- `/games/crash` - Crash game
- `/games/plinko` - Plinko game
- `/leaderboard` - Top players
- `/promotions` - Bonuses & VIP
- `/provably-fair` - Fairness verification

## Smart Contracts (Coming Soon)

The Anchor smart contracts will handle:
- House treasury management
- On-chain RNG verification
- SPL token ($SLOT) staking
- Automated payouts

## License

MIT
